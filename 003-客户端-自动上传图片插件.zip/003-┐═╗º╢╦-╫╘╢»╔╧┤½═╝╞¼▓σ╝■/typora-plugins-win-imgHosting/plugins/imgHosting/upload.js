$(function() {
	//引入其它js文件
	var script = document.createElement("script");
	script.setAttribute("type", "text/javascript");
	script.setAttribute("language", "javascript");
	script.setAttribute("src", "./plugins/imgHosting/tosted.js");
	document.getElementsByTagName("head")[0].appendChild(script);

	var locked = 'doing';
	
    //配置进度条
    var jd = function(evt) {
        if (evt.lengthComputable) {
            var completePercent = Math.round(evt.loaded / evt.total * 100) + "%";
            console.log("上传进度："+ completePercent);
        }
    };

	//配置信息
	var setting = {

		//图片上传地址
		url: 'http://localhost:8866/ImgHosting/upload.action',
		//IDEA测试地址：
		//url: 'http://localhost:8867/upload.action',
		//自定义请求头，做校验
		token: 'ImgUploadForTypora',
		//上传成功
		onSuccess: function(url, msg, num, name) {
			//替换图片位置
			setting.element.removeAttr(locked).attr('src', url);
			setting.element.
			parent('span[md-inline="image"]').
			data('src', url).
			find('.md-image-src-span').
			html("(" + url);
			//判断插入到数据库是否成功
			if (typeof num != "0") {
				setting.element.
				parent('span[md-inline="image"]').
				data('src', url).
				find('.md-image-before-src').
				html("![" + name + "]");
			};
			toasted.success(msg, "typora");

		},
		//上传失败
		onFailure: function(msg) {
			setting.element.removeAttr(locked);
			toasted.error(msg, "typora");
		},
		//ajax判断网络图片链接是否有效
		validateImage: function(url) {
			var xmlHttp;
			if (window.ActiveXObject) {
				xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
			} else if (window.XMLHttpRequest) {
				xmlHttp = new XMLHttpRequest();
			}
			xmlHttp.open("POST", url, true);
			xmlHttp.send();
			if (xmlHttp.status == 404) {
				return false;
			} else {
				return true;
			}
		},
		//上传到服务器
		sendToServer: function(fileData, successCall, failureCall) {
			// 开始上传
			var xhr = new XMLHttpRequest();
			xhr.open("POST", setting.url, true);
			xhr.setRequestHeader("token", setting.token);
			xhr.upload.addEventListener("progress", jd, false);//配置进度条
			xhr.send(fileData);

			// 文件上传成功或是失败
			xhr.onreadystatechange = function(e) {
				if (xhr.readyState == 4) { //请求的状态码，4代表整个数据传输过程结束
					if (xhr.status == 200) { //请求的响应状态，200代表一切正常
						//打印响应数据
						console.log(xhr.responseText); //xhr.responseText：服务器返回的文本数据
						try {
							var json = JSON.parse(xhr.responseText); //将json字符串转为js对象
							if (json.isSuccess) {
								var error = json.extend.message;
								failureCall(error);
							} else {
								var url = json.extend.imgUrl;
								var msg = json.extend.message;
								var num = json.extend.imgId;//-1:后台选择不存到库，0存到数据库失败
								var name = json.extend.localImgPath; //以本地地址作为图片名称显示在网络地址左边

								msg = msg + "\r\n名称:" + json.extend.imgName + "\r\n站点：" + json.extend.site; //log中显示的图片名称为数据库中的图片名称
								successCall(url, msg, num, name);
								console.log(msg + "地址" + url);
							}
						} catch (e) {
							var error = '服务未响应！：' + e.message;
							failureCall(error);
							console.log(error);
						}
					} else {
						var info = '网络未连接或图床服务未开启！';
						console.log(error + xhr.responseText);
						toasted.info(info, "typora");
					};
				};
			};
		},
	};
//文档图片初始化
  $.image = {};
  $.image.init = function(options) {
	options = options || {};
	setting.url = options.url || setting.url;
	setting.headers = options.headers || setting.headers;

	//点击图片事件：mouseleave click事件损失性能，改成单击图片进行上传
	$('#write').on('click', 'img', function(e) {
		try {
			//获取本地图片地址
			var src = e.target.src;
			//获取本地图片名称
			var localname = $(e.target).parent('span[md-inline="image"]').data('src', src).find('.md-image-before-src').html();
			//检测到网络图片做是否失效判断
			var isValid;
			if (/^(https?:)?\/\//i.test(src)) {
				//console.log('准备上传, url:' + src);
				//如果是网络图片则校验该图片链接是否有效
				isValid = setting.validateImage(src);
				if (isValid) {
					//console.log("上传中止：当前图片为网络图片且有效,不做处理：" + localname);
					return false;//false:不重试
				}
				//如果链接无效则 需要获取当前图片名称中的本地图片地址,重新上传
				src = localname;
				console.log("上传重试：当前图片为网络图片且无效,正在尝试重新上传,请勿删除图片名称中的本地地址...");
				return true;
			}

			//console.log("尝试上传：当前图片为本地图片,正在上传,请稍后...")
			//上传
			setting.element = element = $(e.target);
			//给图片地址所在标签添加个属性locked，值为1时正在上传
			var doing = element.attr(locked) == '1';
			if (doing) { //正在上传
				console.log('uploading...');
				return false;
			} else {
				element.attr(locked, '1');
			}
			var data = JSON.stringify({
				localImgPath: src
			})
			//发送上传请求
			setting.sendToServer(data, setting.onSuccess, setting.onFailure);
		} catch (e) {
			console.log(e);
		};
	});
  }; 
  $.image.init();
});
