/**
 * @file js通知
 * @author nreg
 * @createDate 2019-11-13 01:57:26
 **/
function _d_toast_init_css() { 
    var d_toast_text_node = ".zoom-image{"
    +"width:96%;height:0;"
    +"padding-bottom: 97%;"
    +"overflow:hidden;"
    +"background-position: center center;"
    +"background-repeat: no-repeat;"
    +"-webkit-background-size:cover;"
    +"-moz-background-size:cover;"
    +"background-size:cover;"
    +"}"
    +".d-toast-icon{"
    +"width:25px;"
    +"height:25px;"
    +"margin: auto;"
    +"margin-left:20px;"
    +"position: absolute;"
    +"top: 0; left: 0; bottom: 0; right: 0;"
    +"}"
    +".d-toast-close:hover{"
    +"color:#FFFFFF !important"
    +"}"
    +".d-toast{"
    +"-moz-box-shadow: 0 0 6px #999999;"
    +"-webkit-box-shadow: 0 0 6px #999999;"
    +"box-shadow: 0 0 6px #999999;"
    +"overflow: hidden;"
    +"opacity: 0.95;"
    +"-ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=95);"
    +"filter: alpha(opacity=95);"
    +"border-radius: 4px;"
    +"moz-user-select: -moz-none;"
    +"-moz-user-select: none;"
    +"-o-user-select:none;"
    +"-khtml-user-select:none;"
    +"-webkit-user-select:none;"
    +"-ms-user-select:none;"
    +"user-select:none;"
    +"animation:d-toast-left-in 0.5s;"
    +"-moz-animation:d-toast-left-in 0.5s; "
    +"/* Firefox */-webkit-animation:d-toast-left-in 0.5s;"
    +"/* Safari and Chrome */-o-animation:d-toast-left-in 0.5s; "
    +"/* Opera */}.d-toast-close::before{content:\"＋\";}@keyframes d-toast-left-in{from {right:-400px ;}to {right:30px;}}@-moz-keyframes d-toast-left-in"
    +"/* Firefox */{from {right:-400px;}to {right:30px;}}@-webkit-keyframes d-toast-left-in "
    +"/* Safari 和 Chrome */{from {right:-400px;}to {right:30px;}}@-o-keyframes d-toast-left-in "
    +"/* Opera */{from {right:-400px;}to {right:30px;}}@keyframes d-toast-right-out{from{right: 30px;}to{right: -400px;}}@-webkit-keyframes d-toast-right-out{from{right: 30px;}to{right: -400px;}}@-moz-keyframes d-toast-right-out{from{right: 30px;}to{right: -400px;}}@-o-keyframes d-toast-right-out{from{right: 30px;}to{right: -400px;}}.d-toast-close-start{animation: d-toast-right-out 0.5s;-webkit-animation: d-toast-right-out 0.5s;-moz-animation: d-toast-right-out 0.5s;-o-animation: d-toast-right-out 0.5s;}";
    var d_toast_style = document.createElement("style");
    d_toast_style.type = "text/css";
    try {
        d_toast_style.appendChild(document.createTextNode(d_toast_text_node));
    } catch (ex) {
        d_toast_style.styleSheet.cssText = d_toast_text_node;
    };
    var head = document.getElementsByTagName("head")[0]; head.appendChild(d_toast_style);
};

_d_toast_init_css();
var configinit=function(msg,title,icon,bgcolor){
    var config = {
        title: title,//通知标题部分  默认 新消息   可选
        body: msg,//通知内容部分
        inner: true, //是否不调用浏览器通知，false为是，需要浏览器许可
        onclick: function (data) { //监听点击通知   data:可传递参数 可选
            //do something
        },
        timeout: 5000,// 自动关闭 单位毫秒 默认 6500毫秒   timeout<=0 不自动关闭  可选 更改需同时更改247行代码
        //icon:"",//通知的图片 可选
        backgroundColor:bgcolor,//背景色
        titleFontColor:"#000000",//标题字体颜色
        bodyFontColor:"#000000",//消息字体颜色
        dateFontColor:"#000000"//时间字体颜色
    };
    return config;
}
//通知颜色配置
var toasted =  {
    success: function(msg,title,icon) {
        new dToast(new configinit(msg,title,icon,"#fafafa"));//51A351
    },
    error: function(msg, title,icon) {
        new dToast(new configinit(msg, title,icon,"#fafafa"));//BD362F
    },
    info: function(msg, title,icon) {
        new dToast(new configinit(msg,title,icon,"#fafafa"));//2F96B4
    },
    warning:function(msg, title,icon) {
        new dToast(new configinit(msg,title,icon,"#fafafa"));//F89406
    }
}

class dToast {
    constructor(config) {
        if (typeof config == "string") {
            config = { title: config.title, body: config, }
        } else if (typeof config.title == "undefined") {
            config.title = "通知";
        } this.toast(config);
    };
    inner(config) {
        var date = new Date();
        date = date.getFullYear()+"-"+date.getMonth()+"-"+date.getDay()+" "+date.getHours() + ":" + date.getMinutes();//通知时间
        var _div = document.createElement("div");
        var _div_icon = document.createElement("div");
        var _div_content = document.createElement("div");
        var _close = document.createElement('span');
        var _div_img = document.createElement("div");
        var _div_ul = document.createElement("ul");
        var _div_li_1 = document.createElement("li");
        var _div_li_2 = document.createElement("li");
        var _div_li_3 = document.createElement("li");
        _div.oncontextmenu = "return false";
        _div.onselectstart = "return false";
        _close.className = "d-toast-close";
        _close.style.transform = "rotate(45deg)";
        _close.style.webkitTransform = "rotate(45deg)";
        _close.style.mskitTransform = "rotate(45deg)";
        _close.style.mozkitTransform = "rotate(45deg)";
        _close.style.oTransform = "rotate(45deg)";
        _close.style.color = "#ADADAD";
        _close.style.fontSize = "26px";
        _close.style.fontWeight = "normal";
        _close.style.position = "absolute";
        _close.style.top = "6px";
        _close.style.right = "6px";
        _close.style.display = "none";
        _div_icon.style.width = "50px";
        _div_icon.style.height = "50px";
        _div_icon.style.margin = "auto";
        _div_icon.style.marginLeft = "10px";
        _div_icon.style.position = "absolute";
        _div_icon.style.top = "0";
        _div_icon.style.right = "0";
        _div_icon.style.buttom = "0";
        _div_icon.style.right = "0";
        var toast_data = config.data;
        _div_li_1.innerText = config.title;
        _div_li_2.innerText = config.body;
        _div_li_3.innerHTML = date + "<span style='font-size:18px;font-weight:bold;'></span>" + document.domain;
        if (config.icon != undefined && config.icon != null && config.icon != "") {
            _div_img.classList.add("zoom-image");
            _div_img.style.backgroundImage = "url(" + config.icon + ")";
            _div_li_1.style.maxWidth = "260px";
            _div_li_2.style.maxWidth = "260px";
            _div_li_3.style.maxWidth = "260px";
        } else {
            _div_li_1.style.maxWidth = "330px";
            _div_li_2.style.maxWidth = "330px";
            _div_li_3.style.maxWidth = "330px";
            _div_li_1.style.marginLeft = "-10px";
            _div_li_2.style.marginLeft = "-10px";
            _div_li_3.style.marginLeft = "-10px";
        };
        _div_li_1.style.wordWrap = "break-word";
        _div_li_2.style.wordWrap = "break-word";
        _div_li_3.style.wordWrap = "break-word";
        _div.onmouseover = function (e) {
            _close.style.display = "block";
        };
        _div.onmouseout = function (e) {
            _close.style.display = "none";
        };
        _close.onclick = function (e) {
            _div.className = "d-toast-close-start";
            setTimeout(function () {
                _div.remove(); if (typeof onclose == "function") {
                    config.onclose(e);
                }
            }, 500);
        };
        _close.onselectstart = function () {
            return false;
        };
        var toast_items = document.getElementsByClassName("d-toast");
        var _width = 0;
        for (var i = 0; i < toast_items.length; i++) {
            var item = toast_items[i]; _width += item.offsetHeight + 20;
        };
        var _div_bottom = _width + 40;
        var _body_height = document.documentElement.clientHeight;
        if (_body_height - 200 < _div_bottom) {
            for (var i = toast_items.length - 1; i >= 0; i--) {
                toast_items[i].remove();
            }
             _div_bottom = 20;
        };
        if (typeof config.onclick == "function") {
            _div.onclick = function (e) {
                var _target = e.target;
                if (_target.nodeName == "SPAN") {
                    _close.click;
                } else {
                    config.onclick(toast_data);
                };
            };
        };
        _div.style.cursor = "default";
        _div.style.width = "300px";
        _div.style.padding = "1px";
        _div.style.position = "fixed";
        _div.style.bottom = _div_bottom + "px";
        _div.style.right = "20px";
        _div.style.backgroundColor = config.backgroundColor;
        _div_content.style.margin = "10px;";
        _div_content.style.position = "relative";
        _div_content.style.left = "80px";
        _div_ul.style.listStyle = "none";
        _div_ul.style.paddingLeft = "0px";
        _div_ul.style.marginTop = "3px";
        _div_ul.style.marginBottom = "3px";
        _div_li_1.style.color = config.titleFontColor;
        _div_li_1.style.fontFamily="STHeiti,MingLiu !important";
        _div_li_1.style.fontWeight = "normal";
        _div_li_1.style.fontSize = "16px";
        _div_li_2.style.color = config.bodyFontColor;
        _div_li_2.style.fontFamily="'Microsoft YaHei',微软雅黑,STHeiti,MingLiu !important";
        _div_li_2.style.fontSize = "15px";
        _div_li_3.style.color = config.dateFontColor;
        _div_li_3.style.fontFamily="STHeiti,MingLiu !important";
        _div_li_3.style.fontSize = "14px";
        _div_li_3.style.marginTop = "-3px";
        _div.className = "d-toast";
        _div_icon.className = "d-toast-icon";
        _div_content.className = "d-toast-content";
        _div_li_1.className = "d-toast-title";
        _div_li_2.className = "d-toast-body";
        _div_li_3.className = "d-toast-info";
        _div_ul.appendChild(_div_li_1);
        _div_ul.appendChild(_div_li_2);
        _div_ul.appendChild(_div_li_3);
        _div_icon.appendChild(_div_img);
        _div_content.appendChild(_div_ul);
        if (typeof config.icon == "string") {
            _div.appendChild(_div_icon);
        } else {
            _div_content.style.left = "30px";
        };
        _div.appendChild(_div_content);
        _div.appendChild(_close);
        var _d_toast_timeout = config.timeout;
        if (typeof _d_toast_timeout == "undefined") {
            _d_toast_timeout = 5000;
        };
        document.body.appendChild(_div);
        console.log(_d_toast_timeout);
        if (_d_toast_timeout > 0) {
            setTimeout(function () {
                _div.className = "d-toast-close-start";
                setTimeout(function () {
                    _div.remove();
                }, 500);
            }, _d_toast_timeout);
        };
    };
    toast(config) {
        var self = this;
        var toast_config = config;
        if (window.Notification && Notification.permission !== "denied" && config.inner != true) {
            Notification.requestPermission(function (status) {
                if (status == "granted") {
                    var _config = {
                        lang: "zh-CN", tag: "toast-" + (+new Date()), body: config.body,
                    };
                    if (typeof config.icon == "string") {
                        _config.icon = config.icon;
                    };
                    if (typeof config.data != "undefined") {
                        _config.data = config.data;
                    };
                    if (typeof config.timeout != "undefined") {
                        _config.timestamp = config.timeout;
                    };
                    if (typeof config.backgroundColor != "undefined") {
                        _config.backgroundColor = config.backgroundColor;
                    };
                    if (typeof config.titleFontColor != "undefined") {
                        _config.titleFontColor = config.titleFontColor;
                    };
                    if (typeof config.bodyFontColor != "undefined") {
                        _config.bodyFontColor = config.bodyFontColor;
                    };
                    if (typeof config.dateFontColor != "undefined") {
                        _config.dateFontColor = config.dateFontColor;
                    };
                    const d_toast_n = new Notification(config.title, _config);
                    var d_toast_data = config.data;
                    d_toast_n.onclick = function (e) {
                        if (typeof toast_config.onclick == "function") {
                            toast_config.onclick(d_toast_data);
                        };
                    };
                } else {
                    if (config.dev == true) {
                        console.warn('请允许通知！');
                    };
                    self.inner(config);
                };
            });
        } else {
            if (config.dev == true) {
                console.warn("通知插件被浏览器禁止！");
            };
            self.inner(config);
        };
    };
};
