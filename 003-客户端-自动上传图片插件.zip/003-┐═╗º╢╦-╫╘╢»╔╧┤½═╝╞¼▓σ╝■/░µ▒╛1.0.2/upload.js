﻿$(function () {
	//引入其它js文件
	var script = document.createElement("script");
	script.setAttribute("type", "text/javascript");
	script.setAttribute("language", "javascript");
	script.setAttribute("src", "./plugins/imgHosting/tosted.js");
	document.getElementsByTagName("head")[0].appendChild(script);

	//上传方式：0：以本地图片地址上传，要求同域 :直接上传图片地址，服务端直接new一个File请求第三方，效率最快 (不跨域推荐，要求服务端在本地运行)
	//         1:以图片的blob方式上传 ：客户端先将图片转为base64，再将base64转为blob,服务端再将blob转为File，效率最慢，可跨域，不推荐
	//         2：以图片的base64方式上传：客户端先将图片转为base64,服务端再将base64转为File，效率中等，可跨域，（跨域推荐，服务端可在虚拟机、云服务器、树莓派中运行)
	var type = "2";//默认值为2，可跨域
	
	//是否正在上传标识
	var locked = 'doing';
	var imgBase64 = "";
	//配置进度条
	var jd = function (evt) {
		if (evt.lengthComputable) {
			var completePercent = Math.round(evt.loaded / evt.total * 100) + "%";
			console.log("上传进度：" + completePercent);
		}
	};

	//配置信息
	var setting = {
		//图片上传地址
		url: 'http://localhost:8866/ImgHosting/upload.action',
		//IDEA测试地址：
		//url: 'http://localhost:8867/upload.action',
		//请求头，后台会校验
		token: 'Sharing is a quality',
		//上传成功
		onSuccess: function (url, msg, num, name) {
			//替换图片位置
			setting.element.removeAttr(locked).attr('src', url);
			setting.element.
				parent('span[md-inline="image"]').
				data('src', url).
				find('.md-image-src-span').
				html("(" + url);
			//判断插入到数据库是否成功
			if (typeof num != "0") {
				setting.element.
					parent('span[md-inline="image"]').
					data('src', url).
					find('.md-image-before-src').
					html("![" + name + "]");
			};
			toasted.success(msg, "success");

		},
		//上传失败
		onFailure: function (msg) {
			setting.element.removeAttr(locked);
			toasted.error(msg, "error");
		},
		//判断网络图片链接是否有效
		validateImage: function (url) {
			var xmlHttp;
			if (window.ActiveXObject) {
				xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
			} else if (window.XMLHttpRequest) {
				xmlHttp = new XMLHttpRequest();
			}
			xmlHttp.open("POST", url, true);
			xmlHttp.send();
			if (xmlHttp.status == 404) {
				return false;
			} else {
				return true;
			}
		},
		//获取图片base64字符串
		// getBase64: function (imgPath) {
		// 	console.log(imgPath);
		// 	var img = new Image();
		// 	img.src = decodeURI(imgPath);
		// 	img.onload = function () {
		// 		var canvas = document.createElement("canvas");
		// 		canvas.width = img.width;
		// 		canvas.height = img.height;
		// 		var ctx = canvas.getContext("2d");
		// 		ctx.drawImage(img, 0, 0, img.width, img.height);
		// 		base64 = canvas.toDataURL("image/png");
		// 		//console.log(base64);
		// 		return base64;
		// 	}
		// },

		//获取文件base64字符串
		getBase64: function (imgPath, callback) {
			//console.log(imgPath);
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			var img = new Image;//通过构造函数来创建的 img 实例，在赋予 src 值后就会立刻下载图片，相比 createElement() 创建 <img> 省去了 append()，也就避免了文档冗余和污染
			img.crossOrigin = 'Anonymous';
			//要先确保图片完整获取到，这是个异步事件
			img.onload = function () {
				canvas.height = img.height;//确保canvas的尺寸和图片一样
				canvas.width = img.width;
				ctx.drawImage(img, 0, 0);//将图片绘制到canvas中
				var base64 = canvas.toDataURL('image/png');//转换图片为dataURL,传第二个参数可压缩图片,前提是图片格式jpeg或者webp格式的
				callback(base64);//调用回调函数
				canvas = null;
			};
			img.src = imgPath;
		},
		//将base64转换为blob
		base64toBlob: function (dataurl) {
			var arr = dataurl.split(','),
				mime = arr[0].match(/:(.*?);/)[1],
				bstr = atob(arr[1]),
				n = bstr.length,
				u8arr = new Uint8Array(n);
			while (n--) {
				u8arr[n] = bstr.charCodeAt(n);
			}
			return new Blob([u8arr], { type: mime });
		},

		//将base64转换为file (部分浏览器不兼容 File对象)
		base64toFile: function (dataurl, filename) {
			var arr = dataurl.split(',');
			var mime = arr[0].match(/:(.*?);/)[1];
			var bstr = atob(arr[1]);
			var n = bstr.length;
			var u8arr = new Uint8Array(n);
			while (n--) {
				u8arr[n] = bstr.charCodeAt(n);
			}
			//转换成file对象
			return new File([u8arr], filename, { type: mime });
			//转换成成blob对象
			//return new Blob([u8arr],{type:mime});
		},
		//上传到服务器
		sendToServer: function (fileData, successCall, failureCall) {
			// 开始上传
			var xhr = new XMLHttpRequest();
			xhr.open("POST", setting.url, true);//true表示异步
			//xhr.setRequestHeader('Content-Type', 'multipart/form-data')
			//xhr.responseType = 'blob';
			xhr.setRequestHeader("token", setting.token);
			xhr.upload.addEventListener("progress", jd, false);//配置进度条
			xhr.send(fileData);

			// 文件上传成功或是失败
			xhr.onreadystatechange = function (e) {
				if (xhr.readyState == 4) { //请求的状态码，4代表整个数据传输过程结束
					if (xhr.status == 200) { //请求的响应状态，200代表一切正常
						//打印响应数据
						console.log("【响应】" + decodeURI(xhr.responseText)); //xhr.responseText：服务器返回的文本数据
						try {
							var json = JSON.parse(xhr.responseText); //将json字符串转为js对象
							if (json.isSuccess) {
								var error = json.extend.message;
								failureCall(error);
							} else {
								var url = json.extend.imgUrl;
								var msg = json.extend.message;
								var num = json.extend.imgId;//-1:后台选择不存到库，0存到数据库失败
								var name = json.extend.localImgPath; //以本地地址作为图片名称显示在网络地址左边

								//msg = msg + "\r\n名称:" + json.extend.imgName + "\r\n站点：" + json.extend.site; //log中显示的图片名称为数据库中的图片名称
								successCall(url, msg, num, name);
								//console.log(msg + "地址" + url);
							}
						} catch (e) {
							var error = '服务未响应！：' + e.message;
							failureCall(error);
							console.log(decodeURI(error));
						}
					} else {
						var info = '网络未连接或图床服务未开启！';
						console.log(decodeURI(error + xhr.responseText));
						toasted.info(info, "error");
					};
				};
			};
		},
	};
	//文档图片初始化
	$.image = {};
	$.image.init = function (options) {
		options = options || {};
		setting.url = options.url || setting.url;
		setting.headers = options.headers || setting.headers;

		//点击图片事件：mouseleave click事件损失性能，改成单击图片进行上传
		$('#write').on('click', 'img', function (e) {
			try {
				//获取本地图片地址：typora右边的地址
				var src = e.target.src;//本地图片地址  需要去掉 以"file:///"开头和以"?lastModify=数字"结尾 
				//获取本地图片名称：typora左边的地址
				var localname = $(e.target).parent('span[md-inline="image"]').data('src', src).find('.md-image-before-src').html();
				//检测到网络图片做是否失效判断
				var isValid;
				if (/^(https?:)?\/\//i.test(src)) { //如果是网络图片 则判断是否有效
					//console.log('准备上传, url:' + src);
					//如果是网络图片则校验该图片链接是否有效
					isValid = setting.validateImage(src);
					if (isValid) {
						//console.log("上传中止：当前图片为网络图片且有效,不做处理：" + localname);
						return false;//false:不重试
					}
					//如果链接无效则 需要获取当前图片名称中的本地图片地址,重新上传 //如果当前图片名称是本地图片地址 则以"!["开头和"]("结尾 需要去掉
					var reg = new RegExp('(?<=!\\[).+(?=\\]\\()'); //去掉 以"!["开头和"]("结尾
					if (reg.test(localname)) {
						localname = localname.match(reg).toString();
					}
					src = localname;
					console.log("上传重试：当前图片为网络图片且无效,正在尝试重新上传,请勿删除图片名称中的本地地址...：" + src);
					return true;
				} else { //如果是本地图片 
					var reg = new RegExp('(?<=file:///).+(?=\\?lastModify=[0-9]+)'); //去掉 以"file:///"开头和以"?lastModify=数字"结尾 
					if (reg.test(src)) {
						src = src.match(reg).toString();
					}
				}

				//console.log("尝试上传：当前图片为本地图片,正在上传,请稍后...")
				//上传
				setting.element = element = $(e.target);
				//给图片地址所在标签添加个属性locked，值为1时正在上传
				var doing = element.attr(locked) == '1';
				if (doing) { //正在上传
					console.log('uploading...');
					return false;
				} else {
					element.attr(locked, '1');
				}

				src = decodeURI(src);
				//console.log("当前上传方式为：" + type + " src地址为：" + src);

				if ("0" === type) {
					var fileData = new FormData();
					fileData.append("reqImg", src);
					fileData.append("reqType", type);
					console.log("【请求】" + "{reqImg:"+src+",reqType:"+type+"}");
					//发送上传请求
					setting.sendToServer(fileData, setting.onSuccess, setting.onFailure);
				} else if ("1" === type) { //如果是以blob方式上传
					//将图片转成base64
					imgBase64 = setting.getBase64(src, function (base64) {
						var fileData = new FormData();
						//将base64转成blob
						var file = setting.base64toBlob(base64);
						//fileData.encoding="multipart/form-data";
						fileData.append("reqFile", file);
						fileData.append("reqImg", src);
						fileData.append("reqType", type);
						console.log("【请求】" + "{reqImg:"+src+",reqType:"+type+",reqFile:blob方式"+"}");
						//发送上传请求
						setting.sendToServer(fileData, setting.onSuccess, setting.onFailure);
					});
				} else if ("2" === type) { //如果是以base64方式上传
					//将图片转成base64
					imgBase64 = setting.getBase64(src, function (base64) {
						var fileData = new FormData();
						fileData.append("reqImg64", base64);
						fileData.append("reqImg", src);
						fileData.append("reqType", type);
						console.log("【请求】" + "{reqImg:"+src+",reqType:"+type+",reqImg64:base64方式"+"}");
						//发送上传请求 
						setting.sendToServer(fileData, setting.onSuccess, setting.onFailure);
					});
				} else {
					toasted.error("type无效", "error");
				}

				//setTimeout(function () {}, 2000)
			} catch (e) {
				console.log(e);
			};
		});
	};
	$.image.init();
});
