$(function(){
    //相关技术详见：https://segmentfault.com/a/1190000004322487
    //            http://www.ruanyifeng.com/blog/2012/09/xmlhttprequest_level_2.html
    //            https://blog.csdn.net/wangyanming123/article/details/52318183
    //            http://c.biancheng.net/view/4008.html
    //            https://cloud.tencent.com/developer/article/1012288
    var locked = 'doing';
    //用于提示信息的标签id
    var noticeEle = 'image-result-notice';
    //配置信息
    var setting = {
        //图片上传地址
        url: 'http://localhost:8866/upload.action',
        //自定义请求头，做校验，防止其他人随意调接口
        // headers: {
        //     token: 'ImgUploadForTypora'
        // },
        token:'ImgUploadForTypora',
        //上传成功
        onSuccess: function (url, msg) {
            //替换图片位置
            /*            setting.element.removeAttr(locked).attr('src', url);
                        setting.element.
                        parent('span[md-inline="image"]').
                        data('src', url).
                        find('.md-image-src-span').
                        html(url);*/
            //提醒 var text = '图片上传成功：'+ url;
            $('#' + noticeEle).
            css({
                'background': 'rgba(0,166,90,0.7)',
            }).
            html(msg).
            show().
            delay(5000).
            fadeOut();
        },
        //上传失败
        onFailure: function (msg) {
            //setting.element.removeAttr(locked);
            $('#' + noticeEle).
            css({
                'background': 'rgba(255,0,0,0.7)'
            }).
            html(msg).
            show().
            delay(10000).
            fadeOut();
        },
        //上传到服务器
        sendToServer: function (fileData, successCall, failureCall) {
            var xhr = new XMLHttpRequest();
            // 文件上传成功或是失败
            xhr.onreadystatechange = function (e) {
                if (xhr.readyState == 4) { //请求的状态码，4代表整个数据传输过程结束
                    if (xhr.status == 200) { //请求的响应状态，200代表一切正常
                        //打印响应数据
                        console.log(xhr.responseText);//xhr.responseText：服务器返回的文本数据
                        try {
                            var json = JSON.parse(xhr.responseText);//将json字符串转为js对象
                            if (json.isSuccess) {
                                var error = json.message;
                                failureCall(error);
                            } else {
                                var url = json.imgUrl;
                                successCall(url);
                            }
                        } catch (e) {
                            var error = '服务响应解析失败，错误：' + e.message;
                            failureCall(error);
                            console.log(e);
                        }
                    } else {
                        var error = '网络错误，请重试';
                        failureCall(error);
                        console.log(xhr.responseText);
                    }
                }
            };
            // 开始上传
            xhr.open("POST", setting.url, true);
            //请求头
            // for (var key in setting.headers) {
            //     xhr.setRequestHeader(key, setting.headers[key]);
            // }
            xhr.setRequestHeader("token",setting.token);
            xhr.send(fileData);
        },
        //ajax判断网络图片链接是否有效
        validateImage: function (url) {
            var xmlHttp;
            if (window.ActiveXObject) {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            else if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest();
            }
            xmlHttp.open("Get", url, false);
            xmlHttp.send();
            if (xmlHttp.status == 404) {
                return false;
            } else {
                return true;
            }
        }
    }

    //虽然叫upload函数，其实他会先读取文件为base64，再回调上传函数将文件发到服务器
    // var _upload = function(url, object){
    //     var xhr = new XMLHttpRequest();
    //     xhr.onload = function() {
    //         var reader = new FileReader();
    //         reader.onloadend = function() {
    //             setting.sendToServer(reader.result, setting.onSuccess, setting.onFailure);
    //         }
    //         reader.readAsDataURL(xhr.response);
    //     };
    //     xhr.open('GET', url);
    //     xhr.responseType = 'blob';
    //     xhr.send();
    // }

    //文档图片初始化
    $.image = {};
    $.image.init = function (options) {
        options = options || {};
        setting.url = options.url || setting.url;
        setting.headers = options.headers || setting.headers;

        //点击图片离开事件
        // $('#write').on('mouseleave click', 'img', function (e) {
        //     try {
        //         //获取本地图片地址
        //         var src = e.target.src;
        //         //检测到网络图片不做上传处理
        //         if (/^(https?:)?\/\//i.test(src)) {
        //             console.log('The image already upload to server, url:' + src);
        //             // 如果是网络图片则校验该图片链接是否有效
        //             // var boolean= setting.validateImage(src);
        //             // if(boolean==false){ //如果链接有效则不做处理，否则 需要请求从数据库找该网络图片地址对应的本地图片地址，重新上传，日后再议
        //             //
        //             // }
        //             return false;
        //         }
        //         //上传
        //         setting.element = element = $(e.target);
        //         var doing = element.attr(locked) == '1';
        //         if (doing) {
        //             console.log('uploading...');
        //             return false;
        //         } else {
        //             element.attr(locked, '1');
        //         }
        //         //提示标签
        //         $('content').prepend('<div id="' + noticeEle + '" style="position:fixed;height:40px;line-height:40px;padding:0 15px;overflow-y:auto;overflow-x:hidden;z-index:10;color:#fff;width:100%;display:none;"></div>');
        //         //上传
        //         // _upload(src);
        //         setting.sendToServer(src, setting.onSuccess, setting.onFailure);
        //     } catch (e) { console.log(e); };
        // });
        var src ="F:\\picture\\024.png"
        var data = JSON.stringify({
            locationImgPath:src
        })
        setting.sendToServer(data, setting.onSuccess, setting.onFailure);
    };
    $.image.init();
})
//以上仅供服务端测试，部分被注释，用于typora完整js文件如下：
/*
(function ($) {
    var locked = 'doing';
    //用于提示信息的标签id
    var noticeEle = 'image-result-notice';
    //配置信息
    var setting = {
        //图片上传地址
        url: 'http://localhost:8866/upload.action',
        //自定义请求头，做校验，防止其他人随意调接口
        // headers: {
        //     token: 'ImgUploadForTypora'
        // },
        token:'ImgUploadForTypora',
        //上传成功
        onSuccess: function (url, msg) {
            //替换图片位置
            setting.element.removeAttr(locked).attr('src', url);
            setting.element.
            parent('span[md-inline="image"]').
            data('src', url).
            find('.md-image-src-span').
            html(url);
            //提醒 var text = '图片上传成功：'+ url;
            $('#' + noticeEle).
            css({
                'background': 'rgba(0,166,90,0.7)',
            }).
            html(msg).
            show().
            delay(5000).
            fadeOut();
        },
        //上传失败
        onFailure: function (msg) {
            setting.element.removeAttr(locked);
            $('#' + noticeEle).
            css({
                'background': 'rgba(255,0,0,0.7)'
            }).
            html(msg).
            show().
            delay(10000).
            fadeOut();
        },
        //上传到服务器
        sendToServer: function (fileData, successCall, failureCall) {
            var xhr = new XMLHttpRequest();
            // 文件上传成功或是失败
            xhr.onreadystatechange = function (e) {
                if (xhr.readyState == 4) { //请求的状态码，4代表整个数据传输过程结束
                    if (xhr.status == 200) { //请求的响应状态，200代表一切正常
                        //打印响应数据
                        console.log(xhr.responseText);//xhr.responseText：服务器返回的文本数据
                        try {
                            var json = JSON.parse(xhr.responseText);//将json字符串转为js对象
                            if (json.isSuccess) {
                                var error = json.extend.message;
                                failureCall(error);
                            } else {
                                var url = json.extend.imgUrl;
                                var msg=json.extend.message;
                                successCall(url,msg);
                            }
                        } catch (e) {
                            var error = '服务响应解析失败，错误：' + e.message;
                            failureCall(error);
                            console.log(e);
                        }
                    } else {
                        var error = '网络错误，请重试';
                        failureCall(error);
                        console.log(xhr.responseText);
                    }
                }
            };
            // 开始上传
            xhr.open("POST", setting.url, true);
            //请求头
            // for (var key in setting.headers) {
            //     xhr.setRequestHeader(key, setting.headers[key]);
            // }
            xhr.setRequestHeader("token",setting.token);
            xhr.send(fileData);
        },
        //ajax判断网络图片链接是否有效
        validateImage: function (url) {
            var xmlHttp;
            if (window.ActiveXObject) {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            else if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest();
            }
            xmlHttp.open("Get", url, false);
            xmlHttp.send();
            if (xmlHttp.status == 404) {
                return false;
            } else {
                return true;
            }
        }
    };

    //文档图片初始化
    $.image = {};
    $.image.init = function (options) {
        options = options || {};
        setting.url = options.url || setting.url;
        setting.headers = options.headers || setting.headers;

        //点击图片离开事件
        $('#write').on('mouseleave click', 'img', function (e) {
            try {
                //获取本地图片地址
                var src = e.target.src;
                //检测到网络图片不做上传处理
                if (/^(https?:)?\/\//i.test(src)) {
                    console.log('The image already upload to server, url:' + src);
                    return false;
                }

                //上传
                setting.element = element = $(e.target);
                var doing = element.attr(locked) == '1';
                if (doing) {
                    console.log('uploading...');
                    return false;
                } else {
                    element.attr(locked, '1');
                }
                //提示标签 在标签的开头插入提示信息（标签）
                $('content').prepend('<div id="' + noticeEle + '" style="position:fixed;height:40px;line-height:40px;padding:0 15px;overflow-y:auto;overflow-x:hidden;z-index:10;color:#fff;width:100%;display:none;"></div>');
                //上传
                // _upload(src);
                var data = JSON.stringify({
                    locationImgPath:src
                })
                setting.sendToServer(data, setting.onSuccess, setting.onFailure);
            } catch (e) { console.log(e); };
        });
    };
})(jQuery);

$.image.init();

*/
