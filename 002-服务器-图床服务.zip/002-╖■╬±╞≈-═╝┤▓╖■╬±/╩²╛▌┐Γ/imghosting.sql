/*
Navicat MySQL Data Transfer

Source Server         : MySql
Source Server Version : 80016
Source Host           : localhost:3306
Source Database       : imghosting

Target Server Type    : MYSQL
Target Server Version : 80016
File Encoding         : 65001

Date: 2019-12-05 20:34:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `imginfo`
-- ----------------------------
DROP TABLE IF EXISTS `imginfo`;
CREATE TABLE `imginfo` (
  `img_id` bigint(255) NOT NULL AUTO_INCREMENT,
  `img_name` varchar(255) DEFAULT NULL,
  `img_local_addr` varchar(255) DEFAULT NULL,
  `img_web_addr` varchar(255) DEFAULT NULL,
  `doc_name` varchar(255) DEFAULT NULL,
  `site_num` int(255) DEFAULT NULL,
  PRIMARY KEY (`img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=480 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of imginfo
-- ----------------------------
