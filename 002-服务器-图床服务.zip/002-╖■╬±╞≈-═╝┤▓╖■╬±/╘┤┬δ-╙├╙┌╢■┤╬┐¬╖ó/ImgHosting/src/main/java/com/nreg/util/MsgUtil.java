package com.nreg.util;

import java.util.HashMap;
import java.util.Map;

/**
 * 通用类：返回Json数据的状态类(响应类)
 * @author nreg
 * @create 2019/8/1 18:27
 */
public class MsgUtil {

    //状态码(响应码)
    private int code;
    //提示信息
    private String msg;
    //响应信息：处理器返回给浏览器的数据,用于携带参数返回
    private Map<String,Object> extend = new HashMap();
    //getter、setter方法快捷键生成

    //2个状态方法
    public static MsgUtil success(){
        MsgUtil result = new MsgUtil();
        //设置状态码:89757，代表服务器处理成功
        result.setCode(89757);
        result.setMsg("处理成功!");
        return result;
    }
    public static MsgUtil failed(){
        MsgUtil result = new MsgUtil();
        //设置状态码:75798，代表服务器处理失败
        result.setCode(75798);
        result.setMsg("处理失败!");
        return result;
    }

    //可用于携带参数的链式操作(能不断.add()携带参数)
    public MsgUtil add(String key, Object value){
        this.getExtend().put(key,value);
        return  this;
    }

    //以下getter、setter方法快捷键生成

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Map<String, Object> getExtend() {
        return extend;
    }

    public void setExtend(Map<String, Object> extend) {
        this.extend = extend;
    }
}

