package com.nreg.controller;

import com.nreg.plugin.imghosting.domain.ImageHostingResponse;
import com.nreg.service.ImgInfoService;
import com.nreg.service.ImgUploadService;
import com.nreg.util.MsgUtil;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Title:
 * Packet:com.nreg.controller
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/10.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */

@Controller
public class ImgHostingController {
    //调用外部属性文件的属性，用于解决硬编码，需要在spring-mvc.xml中配置
    @Value("${jdbc.url}")
    private String URL;
    @Value("${jdbc.username}")
    private String USER_NAME;
    @Value("${jdbc.password}")
    private String USER_PASSWORD;
    @Autowired
    ImgUploadService imgUploadService;
    @Autowired
    ImgInfoService imgInfoService;

    //请求映射：根据具体请求，配置具体处理方法，.action可省略，value可以是数组
    @RequestMapping("/upload.action")
    @ResponseBody //将返回值转换为JSON字符串类型
    // Msg为分页状态信息类，用于提供删除成功、增加成功等状态信息
    public MsgUtil getCustomerWithJson(@RequestBody String requestInfo, HttpServletRequest request) { //@RequestBody String requestInfo://将Json字符串转为对象类型
        System.out.println("***********************************************************");
        //获取请求参数：本地图片地址
        JSONObject jsonObject = JSONObject.fromObject(requestInfo);//用阿里巴巴的：JSONObject obj = JSON.parseObject(requestInfo);
        String imgPath = null;
        try {
            //避免中文乱码,该key必须为客户端上送的名称，否则报500错误
            imgPath = URLDecoder.decode(jsonObject.getString("localImgPath"), "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        //图片地址校验
        if (imgPath == "" || imgPath == null || imgPath.length() == 0) {
            System.out.println("本地图片地址校验失败");
            return MsgUtil.failed().add("message", "参数错误");
        }

        //typora客户端上传的图片地址会以"file:///"开头和以"?lastModify=数字"结尾
        String localImgPath = imgPath;
        String regex = "^file:///";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(imgPath);
        while (m.find()) { //如果是^file:///开头的则进行下一步
            String regex2 = "(?<=file:///).+(?=\\?lastModify=[0-9]+)"; //去掉开头的"file:///"和结尾的"?lastModify=数字"
            Pattern p2 = Pattern.compile(regex2);
            Matcher m2 = p2.matcher(imgPath);
            while (m2.find()) {
                localImgPath = m2.group();
            }
        }

        //客户端初始化文档时检查到失效的网络图片后上传的本地图片会以"!["开头和"]("结尾(是从typora图片名称中获取的)
        String regex3 = "^!\\[";
        Pattern p3 = Pattern.compile(regex3);
        Matcher m3 = p3.matcher(localImgPath);
        while (m3.find()) { //如果是"!["开头的则进行下一步
            String regex4 = "(?<=!\\[).+(?=\\]\\()"; //去掉开头的"!["和结尾的"]("
            Pattern p4 = Pattern.compile(regex4);
            Matcher m4 = p4.matcher(localImgPath);
            while (m4.find()) {
                localImgPath = m4.group();
            }
        }

        //匹配后的图片地址再次校验
        if (localImgPath == "" || localImgPath == null || localImgPath.length() == 0) {
            System.out.println("本地图片地址校验失败");
            return MsgUtil.failed().add("message", "参数错误");
        }

        System.out.println("本地图片地址：" + localImgPath);

        //获取请求头
        String token = "";
        Enumeration<String> es = request.getHeaders("token");
        while (es.hasMoreElements()) {
            token = es.nextElement();
        }
        //请求头校验
        if (!token.contains("ImgUploadForTypora")) {
            return MsgUtil.failed().add("message", "校验失败");
        }

        //上送本地图片地址，返回网络图片地址，将上传到8大站点，只要有一个站点上传成功就立刻返回图片地址，因此网络图片地址只有一个
        ImageHostingResponse imageHostingResponse = imgUploadService.imgUpload(localImgPath);
        //从响应中获取需要的参数
        boolean isSuccess = imageHostingResponse.isSuccess();
        int siteNum = imageHostingResponse.getImageDO().getPlatform();
        String message = imageHostingResponse.getMessage();
        //8大站点全上传失败，为保险起见返回本地图片地址，但前端依然需要做判断，8大站点全失败，前端判断后不需要做图片替换操作
        if (!isSuccess) {
            return MsgUtil.failed().add("imgUrl", localImgPath).add("message", message).add("isSuccess", isSuccess).add("site", siteNum);
        }

        //如果上传成功则返回网络图片
        String imgUrl = imageHostingResponse.getImageDO().getAbsoluteUrl();
        System.out.println("网络图片地址：" + imgUrl);

        //生成图片名称：只用于存到数据库，在typora客户端显示图片名称的地方会以本地图片地址展示，有利于客户端实现文档初始化时检查网络地址是否失效，如果失效则直接上传图片名称中的本地地址，而不必请求数据库去查
        String imgName = "img-"+UUID.randomUUID().toString().replace("-", "").substring(0, 20);
        System.out.println("图片名称：" + imgName);

/*        //如果数据库不可以连接，不存储到数据库，依然返回网络图片地址，前台依然会做替换，在typora中会把本地地址放在网络地址的左边-图片名称那块显示
        if (!DbConn.isconn()) {
            //使用状态信息类MsgUtil携带参数返回
            return MsgUtil.success().add("imgUrl", imgUrl).add("message", message).add("isSuccess", isSuccess).add("site", siteNum).add("imgName", imgName).add("localImgPath",localImgPath);
        }

        //将图片信息存储到数据库
        ImgInfo imgInfo = new ImgInfo();
        imgInfo.setImgName(imgName);
        imgInfo.setImgLocalAddr(localImgPath);
        imgInfo.setImgWebAddr(imgUrl);
        imgInfo.setSiteNum(siteNum);

        //插入数据后返回0或1，1代表插入成功，如果是1该方法返回自增字段id，即imgId,否则返回0，用于前台校验是否插入数据库成功
        Long imgId = imgInfoService.addImgInfo(imgInfo);
        System.out.println("数据库连接成功");
        System.out.println("图片id：" + imgId);
        System.out.println("***********************************************************");
        return MsgUtil.success().add("imgUrl", imgUrl).add("message", message).add("isSuccess", isSuccess).add("site", siteNum).add("imgName", imgName).add("imgId", imgId).add("localImgPath",localImgPath);*/

        //如果要使用数据库记录图片位置信息则解决上面的注释并删除下一行代码：
        return MsgUtil.success().add("imgUrl", imgUrl).add("message", message).add("isSuccess", isSuccess).add("site", siteNum).add("imgName", imgName).add("imgId", -1).add("localImgPath",localImgPath);
    }
}
