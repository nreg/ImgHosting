package com.nreg.plugin.imghosting.service;
/**
 *	@author kalman03
 *	@since	2019-08-17
 */

import com.nreg.plugin.imghosting.domain.ImageHostingReqConfig;

import java.io.File;
import java.io.IOException;

public interface InnerImageUploadService {
	/**
	 *
	 * @param imageFile 图片地址
	 * @param reqConfig 超时
	 * @return
	 * @throws IOException
	 */
	String upload(File imageFile, ImageHostingReqConfig reqConfig)throws IOException;
}
