package com.nreg.service.impl;

import com.nreg.bean.ImgInfo;
import com.nreg.mapper.ImgInfoMapper;
import com.nreg.service.ImgInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Title:
 * Packet:com.nreg.service.impl
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/14.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
@Service("ImgInfoService")
@Transactional
public class ImgInfoServiceImpl implements ImgInfoService {
    @Autowired
    private ImgInfoMapper imgInfoMapper;
    @Override
    public Long addImgInfo(ImgInfo imgInfo) {
        Long aLong = imgInfoMapper.addImgInfo(imgInfo);
        //如果插入成功，返回自增字段id，否则返回0
        if (aLong==1) {
            return imgInfo.getImgId();
        }
        return 0L;
    }
}
