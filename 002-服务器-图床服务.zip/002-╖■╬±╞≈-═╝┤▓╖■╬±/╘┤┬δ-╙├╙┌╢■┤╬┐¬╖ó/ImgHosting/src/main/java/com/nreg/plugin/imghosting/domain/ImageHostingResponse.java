package com.nreg.plugin.imghosting.domain;

import lombok.Data;

/**
 * 图床站点响应实体
 */
@Data
public class ImageHostingResponse {
	private ImageDO imageDO;
	private boolean success;
	private String message;

	public ImageDO getImageDO() {		return imageDO;	}
	public void setImageDO(ImageDO imageDO) {		this.imageDO = imageDO;	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	@Data
	public static class ImageDO{
		private String absoluteUrl;
		private int platform;

		public String getAbsoluteUrl() {
			return absoluteUrl;
		}
		public void setAbsoluteUrl(String absoluteUrl) {
			this.absoluteUrl = absoluteUrl;
		}
		public int getPlatform() {
			return platform;
		}
		public void setPlatform(int platform) {
			this.platform = platform;
		}
	}
}