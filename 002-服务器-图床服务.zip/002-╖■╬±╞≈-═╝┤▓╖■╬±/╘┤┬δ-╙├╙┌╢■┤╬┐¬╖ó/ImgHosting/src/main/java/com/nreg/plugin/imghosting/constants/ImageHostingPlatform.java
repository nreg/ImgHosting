package com.nreg.plugin.imghosting.constants;

import java.util.Arrays;
import java.util.List;

/**
 * 图床站点
 * 
 * @author kalman03
 * @since 2019-08-17
 */
public class ImageHostingPlatform {
	/**
	 * 掘金
	 */
	public final static int JUEJIN = 1;
	/**
	 * 苏宁
	 */
	public final static int SUNING = 2;
	/**
	 * 网易
	 */
	public final static int NETEASE = 3;
	/**
	 * 搜狐
	 */
	public final static int SOUHU = 4;
	/**
	 * 今日头条
	 */
	public final static int BYTEDANCE = 5;
	/**
	 * CC
	 */
	public final static int CC = 6;
	/**
	 * aliexpress ，在微信里面可能无法直接打开
	 */
	public final static int ALIEXPRESS = 7;
	/**
	 * 京东，不支持尺寸太小的图片
	 */
	public final static int JD = 8;

	public final static List<Integer> ALL_HOSTING_PLATFORMS = Arrays.asList(JUEJIN, CC, NETEASE, SUNING, ALIEXPRESS, JD,
			BYTEDANCE, SOUHU);
}
