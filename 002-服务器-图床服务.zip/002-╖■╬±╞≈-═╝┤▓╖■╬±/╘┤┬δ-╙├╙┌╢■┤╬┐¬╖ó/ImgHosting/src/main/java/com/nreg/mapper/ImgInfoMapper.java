package com.nreg.mapper;

import com.nreg.bean.ImgInfo;

/**
 * Title:
 * Packet:com.nreg.mapper
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/14.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
public interface ImgInfoMapper {
    Long addImgInfo(ImgInfo imgInfo);
}
