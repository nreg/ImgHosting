//package com.nreg.plugin.imghosting.test;
//
//import com.nreg.plugin.imghosting.constants.ImageHostingPlatform;
//import com.nreg.plugin.imghosting.domain.ImageHostingOptions;
//import com.nreg.plugin.imghosting.domain.ImageHostingResponse;
//import com.nreg.plugin.imghosting.upload.ImageHostingService;
//import com.nreg.plugin.imghosting.upload.impl.DefaultImageHostingService;
//
//import java.io.File;
//import java.util.Arrays;
//
///**
// * Hello world!
// */
//public class App {
//	public static void main(String[] args) {
//		try {
//			//要上传的图片
//			File imageFile = new File("F:\\picture\\壁纸\\5bbc94fe9a829.jpg");
//			//要上传的站点
//			ImageHostingOptions options = new ImageHostingOptions();
//			options.setHostingPlatforms(Arrays.asList(ImageHostingPlatform.JUEJIN));
//			//上传图片及参数(后缀、站点、超时)
//			ImageHostingService imageHostingService = new DefaultImageHostingService();
//			ImageHostingResponse response = imageHostingService.upload(imageFile, options);
//			//System.out.println(JSON.toJSONString(response));
//			/*
//			{
//				"imageDO": {
//				"absoluteUrl": "https://user-gold-cdn.xitu.io/2019/11/10/16e534200c5fb0df?w=1920&h=1200&f=jpeg&s=1077847",
//				"platform": 8
//				},
//				"message": "上传成功",
//				"success": true
//				}*/
//			System.out.println(response.getImageDO().getAbsoluteUrl());//上传成功返回的网络图片地址
//			System.out.println(response.getMessage());//响应信息
//			System.out.println(response.isSuccess());//是否上传成功
//			System.out.println(response.getImageDO().getPlatform());//上传到的站点代号
///*			https://user-gold-cdn.xitu.io/2019/11/10/16e5400a15907029?w=1920&h=1200&f=jpeg&s=1077847
//			上传成功
//			true*/
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//}
//
