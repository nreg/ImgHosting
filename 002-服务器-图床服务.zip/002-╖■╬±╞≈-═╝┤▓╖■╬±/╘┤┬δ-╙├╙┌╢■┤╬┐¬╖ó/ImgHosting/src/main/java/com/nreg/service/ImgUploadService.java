package com.nreg.service;

import com.nreg.plugin.imghosting.domain.ImageHostingResponse;

import java.util.List;

/**
 * Title:
 * Packet:com.nreg.service
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/10.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
public interface ImgUploadService {
    ImageHostingResponse imgUpload(String locationImgPath);
}
