package com.nreg.plugin.imghosting.domain;

import lombok.Data;

/**
 *	@author kalman03
 *	@since	2019-08-17
 */
@Data
public class ImageHostingReqConfig {
	private int connetionTimeOut = 1000*3;
	private int socketTimeout = 1000*3;

	public int getConnetionTimeOut() {		return connetionTimeOut;	}
	public void setConnetionTimeOut(int connetionTimeOut) {		this.connetionTimeOut = connetionTimeOut;	}
	public int getSocketTimeout() {		return socketTimeout;	}
	public void setSocketTimeout(int socketTimeout) {		this.socketTimeout = socketTimeout;	}

}
