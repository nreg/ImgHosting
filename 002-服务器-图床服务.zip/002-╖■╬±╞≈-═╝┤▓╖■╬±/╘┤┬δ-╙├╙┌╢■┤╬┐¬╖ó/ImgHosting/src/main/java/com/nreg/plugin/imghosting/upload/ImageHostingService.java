package com.nreg.plugin.imghosting.upload;

import com.nreg.plugin.imghosting.domain.ImageHostingOptions;
import com.nreg.plugin.imghosting.domain.ImageHostingResponse;

import java.io.File;
import java.io.IOException;

/**
 * @author kalman03
 * @since 2019-08-17
 */
public interface ImageHostingService {

	ImageHostingResponse upload(byte[] imageBytes, ImageHostingOptions options)throws IOException;

	ImageHostingResponse upload(File imageFile, ImageHostingOptions options)throws IOException;
}
