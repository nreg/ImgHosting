package com.nreg.bean;

import java.util.Objects;

/**
 * Title:
 * Packet:com.nreg.bean
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/14.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
public class ImgInfo {
    private Long imgId;
    private String imgName;
    private String imgLocalAddr;
    private String imgWebAddr;
    private String docName;
    private int siteNum;

    public ImgInfo() {
    }

    public Long getImgId() {
        return imgId;
    }

    public void setImgId(Long imgId) {
        this.imgId = imgId;
    }

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }

    public String getImgLocalAddr() {
        return imgLocalAddr;
    }

    public void setImgLocalAddr(String imgLocalAddr) {
        this.imgLocalAddr = imgLocalAddr;
    }

    public String getImgWebAddr() {
        return imgWebAddr;
    }

    public void setImgWebAddr(String imgWebAddr) {
        this.imgWebAddr = imgWebAddr;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public int getSiteNum() {
        return siteNum;
    }

    public void setSiteNum(int siteNum) {
        this.siteNum = siteNum;
    }

    @Override
    public String toString() {
        return "ImgInfo{" +
                "imgId=" + imgId +
                ", imgName='" + imgName + '\'' +
                ", imgLocalAddr='" + imgLocalAddr + '\'' +
                ", imgWebAddr='" + imgWebAddr + '\'' +
                ", docName='" + docName + '\'' +
                ", siteNum=" + siteNum +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImgInfo imgInfo = (ImgInfo) o;
        return siteNum == imgInfo.siteNum &&
                Objects.equals(imgId, imgInfo.imgId) &&
                Objects.equals(imgName, imgInfo.imgName) &&
                Objects.equals(imgLocalAddr, imgInfo.imgLocalAddr) &&
                Objects.equals(imgWebAddr, imgInfo.imgWebAddr) &&
                Objects.equals(docName, imgInfo.docName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imgId, imgName, imgLocalAddr, imgWebAddr, docName, siteNum);
    }
}
