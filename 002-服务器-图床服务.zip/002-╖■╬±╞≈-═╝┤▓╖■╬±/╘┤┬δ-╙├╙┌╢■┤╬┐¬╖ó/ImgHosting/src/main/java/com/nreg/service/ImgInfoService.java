package com.nreg.service;

import com.nreg.bean.ImgInfo;

/**
 * Title:
 * Packet:com.nreg.service
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/14.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
public interface ImgInfoService {
    /**
     * 添加图片信息
     * @param imgInfo
     * @return
     */
    Long addImgInfo(ImgInfo imgInfo);
}
