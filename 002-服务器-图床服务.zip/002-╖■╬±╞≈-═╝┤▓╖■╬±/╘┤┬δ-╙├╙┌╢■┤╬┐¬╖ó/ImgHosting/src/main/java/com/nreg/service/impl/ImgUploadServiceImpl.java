package com.nreg.service.impl;

import com.nreg.plugin.imghosting.constants.ImageHostingPlatform;
import com.nreg.plugin.imghosting.domain.ImageHostingOptions;
import com.nreg.plugin.imghosting.domain.ImageHostingResponse;
import com.nreg.plugin.imghosting.upload.ImageHostingService;
import com.nreg.plugin.imghosting.upload.impl.DefaultImageHostingService;
import com.nreg.service.ImgUploadService;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Title:
 * Packet:com.nreg.service.impl
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/10.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */@Service("ImgUploadService")
public class ImgUploadServiceImpl implements ImgUploadService {
    @Override
    public ImageHostingResponse imgUpload(String locationImgPath) {
        try {
            //要上传的图片
            File imageFile = new File(locationImgPath);
            //要上传的站点，只要有一个站点上传成功就返回
            ImageHostingOptions options = new ImageHostingOptions();
            List<Integer> siteNum=new ArrayList<>();
            siteNum.add(ImageHostingPlatform.JUEJIN);
            siteNum.add(ImageHostingPlatform.SUNING);
            siteNum.add(ImageHostingPlatform.NETEASE);
            siteNum.add(ImageHostingPlatform.SOUHU);
            siteNum.add(ImageHostingPlatform.BYTEDANCE);
            siteNum.add(ImageHostingPlatform.CC);
            siteNum.add(ImageHostingPlatform.ALIEXPRESS);
            siteNum.add(ImageHostingPlatform.JD);
            options.setHostingPlatforms(siteNum);

            //上传图片及参数(后缀、站点、超时)
            ImageHostingService imageHostingService = new DefaultImageHostingService();
            ImageHostingResponse response = imageHostingService.upload(imageFile, options);
            //System.out.println(JSON.toJSONString(response));
            return  response;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
