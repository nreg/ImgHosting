package com.nreg.util;

import javax.swing.*;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Title:
 * Packet:com.nreg.util
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/14.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
public class DbConn {
    //测试数据库连接
    public static boolean isconn(){
        boolean iscon = true;

        String url="jdbc:mysql://localhost:3306/imghosting?useSSL=false&serverTimezone=UTC&characterEncoding=utf8";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");//加载驱动类
            DriverManager.getConnection(url, "root", "211618");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            iscon=false;
            System.out.println("数据库连接失败");
        }
        return iscon;
    }
}
