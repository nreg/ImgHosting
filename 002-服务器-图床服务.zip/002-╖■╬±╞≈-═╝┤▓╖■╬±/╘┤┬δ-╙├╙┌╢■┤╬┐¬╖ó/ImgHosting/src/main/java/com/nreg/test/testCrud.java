package com.nreg.test;

import com.nreg.bean.ImgInfo;
import com.nreg.service.ImgInfoService;
import com.nreg.service.impl.ImgInfoServiceImpl;

/**
 * Title:
 * Packet:com.nreg.test
 * Description:
 * Author:WangYang
 * Create Date: 2019/11/14.
 * Modify User:
 * Modify Date:
 * Modify Description:
 */
public class testCrud {
    ImgInfoService imgInfoService =new ImgInfoServiceImpl();
    //@Test
    public void test(){
        ImgInfo imgInfo = new ImgInfo();
        imgInfo.setImgName("imgName");
        imgInfo.setImgLocalAddr("locationImgPath");
        imgInfo.setImgWebAddr("imgUrl");
        imgInfo.setSiteNum(2);
        //只有图片存储到数据库成功才会返回imgId
        Long imgId = null;
        try {
            imgId = imgInfoService.addImgInfo(imgInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("图片id："+imgId);
    }
}
